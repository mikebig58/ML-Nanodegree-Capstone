Environment setup:

Python version: 3.6.5

Libraries to install: lightGBM

conda install -c conda-forge lightgbm 

link to capstone proposal: https://review.udacity.com/#!/reviews/1479047